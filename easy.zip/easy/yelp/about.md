


Signup
 - https://www.yelp.com/login?return_url=/developers/v3/manage_app

https://docs.developer.yelp.com/reference/v3_business_search
https://github.com/georgiev-martin/yelp-api-v3/blob/master/docs/api-references/businesses-search.md



```
curl --request GET \
     --url 'https://api.yelp.com/v3/businesses/search?sort_by=best_match&limit=20' \
     --header 'accept: application/json'
```


