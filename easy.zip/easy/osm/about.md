

https://nominatim.org/release-docs/develop/api/Search/


```
curl -v -o that.txt 'https://photon.komoot.io/api/?q=1000+5th+Avenue,New+York,NY'
```


